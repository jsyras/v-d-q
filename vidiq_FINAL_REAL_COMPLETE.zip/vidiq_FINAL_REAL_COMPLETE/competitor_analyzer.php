<?php include("template/header.php"); ?>

<h2>Competitor Analyzer</h2>
<form method="post">
  <input type="text" name="input" placeholder="Masukkan input..." required>
  <button type="submit">Jalankan</button>
</form>
<div class="result">
  <?php
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = escapeshellarg($_POST['input']);
    $output = shell_exec("python3 py/competitor_compare.py $input");
    echo "<pre>" . htmlspecialchars($output) . "</pre>";
  }
  ?>
</div>

<?php include("template/footer.php"); ?>