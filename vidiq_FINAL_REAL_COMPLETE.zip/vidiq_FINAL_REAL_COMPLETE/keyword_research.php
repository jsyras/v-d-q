<?php include("template/header.php"); ?>

<div class="container">
        <h2>Keyword Research</h2>
        <form method="post">
            <label>Masukkan Keyword:</label>
            <input type="text" name="keyword" required><br><br>
            <button type="submit">Cari</button>
        </form>

        <div class="result">
            <?php
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $keyword = escapeshellarg($_POST['keyword']);
                $output = shell_exec("python3 py/keyword_research.py $keyword");
                $data = json_decode($output, true);

                if (!$data || isset($data['error'])) {
                    echo "<p>Gagal mengambil data keyword.</p>";
                } else {
                    echo "<h3>Hasil Riset:</h3>";
                    echo "<ul>";
                    foreach ($data as $tag => $score) {
                        echo "<li><strong>" . htmlspecialchars($tag) . "</strong>: " . htmlspecialchars($score) . "%</li>";
                    }
                    echo "</ul>";
                }
            }
            ?>
        </div>
    </div>
<?php include("template/footer.php"); ?>