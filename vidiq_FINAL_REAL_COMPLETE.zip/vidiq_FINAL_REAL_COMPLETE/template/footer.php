</main>
<footer class="bg-white border-top text-center py-4 mt-auto" id="main-footer">
<div class="container text-muted small">
    © 2024 YouTube SEO Tools. All rights reserved.
   </div>
</footer>
<script>
    const darkModeToggle = document.getElementById('dark-mode-toggle');
    const darkModeIcon = document.getElementById('dark-mode-icon');
    const body = document.body;
    const navbar = document.getElementById('main-navbar');
    const footer = document.getElementById('main-footer');
    const cards = document.querySelectorAll('.card');
    const menuToggleButton = document.getElementById('menu-toggle-button');
    const mobileMenu = document.getElementById('mobile-menu');
    const menuIcon = document.getElementById('menu-icon');

    function setDarkMode(isDark) {
      if (isDark) {
        body.classList.add('dark-mode');
        navbar.classList.add('navbar-dark-mode');
        footer.classList.add('bg-dark', 'text-light');
        cards.forEach(card => card.classList.add('card-dark-mode'));
        darkModeIcon.classList.remove('fa-moon');
        darkModeIcon.classList.add('fa-sun', 'rotate-180');
        darkModeIcon.classList.remove('rotate-0');
        localStorage.setItem('theme', 'dark');
        darkModeToggle.setAttribute('aria-pressed', 'true');
      } else {
        body.classList.remove('dark-mode');
        navbar.classList.remove('navbar-dark-mode');
        footer.classList.remove('bg-dark', 'text-light');
        cards.forEach(card => card.classList.remove('card-dark-mode'));
        darkModeIcon.classList.remove('fa-sun', 'rotate-180');
        darkModeIcon.classList.add('fa-moon', 'rotate-0');
        darkModeIcon.classList.remove('rotate-180');
        localStorage.setItem('theme', 'light');
        darkModeToggle.setAttribute('aria-pressed', 'false');
      }
    }

    (function () {
      const savedTheme = localStorage.getItem('theme');
      if (savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        setDarkMode(true);
      } else {
        setDarkMode(false);
      }
    })();

    darkModeToggle.addEventListener('click', () => {
      const isDark = body.classList.contains('dark-mode');
      setDarkMode(!isDark);
    });

    // Menu toggle with rotation animation
    menuToggleButton.addEventListener('click', (e) => {
      e.stopPropagation();
      const isShown = mobileMenu.classList.contains('show');
      if (isShown) {
        mobileMenu.classList.remove('show');
        menuIcon.classList.remove('rotate-180');
        menuIcon.classList.add('rotate-0');
        menuToggleButton.setAttribute('aria-expanded', 'false');
      } else {
        mobileMenu.classList.add('show');
        menuIcon.classList.add('rotate-180');
        menuIcon.classList.remove('rotate-0');
        menuToggleButton.setAttribute('aria-expanded', 'true');
        mobileMenu.focus();
      }
    });

    // Close menu when clicking outside
    document.addEventListener('click', (e) => {
      if (mobileMenu.classList.contains('show')) {
        if (!mobileMenu.contains(e.target) && e.target !== menuToggleButton && !menuToggleButton.contains(e.target)) {
          mobileMenu.classList.remove('show');
          menuIcon.classList.remove('rotate-180');
          menuIcon.classList.add('rotate-0');
          menuToggleButton.setAttribute('aria-expanded', 'false');
        }
      }
    });

    // Close menu on Escape key when focused inside menu
    mobileMenu.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        mobileMenu.classList.remove('show');
        menuIcon.classList.remove('rotate-180');
        menuIcon.classList.add('rotate-0');
        menuToggleButton.setAttribute('aria-expanded', 'false');
        menuToggleButton.focus();
      }
    });
  </script>
</body>
</html>