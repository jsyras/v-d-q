<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1" name="viewport"/>
<title>YouTube SEO Tools</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&amp;display=swap" rel="stylesheet"/>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
<style>
    body {
      font-family: 'Inter', sans-serif;
      background-color: #f9fafb;
      color: #212529;
      transition: background-color 0.3s, color 0.3s;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }
    body.dark-mode {
      background-color: #121212;
      color: #e4e4e7;
    }
    .navbar-dark-mode {
      background-color: #212529 !important;
    }
    .card-dark-mode {
      background-color: #2c2c2c;
      color: #e4e4e7;
      border-color: #444;
    }
    .btn-primary {
      background-color: #2563eb;
      border-color: #2563eb;
    }
    .btn-primary:hover,
    .btn-primary:focus {
      background-color: #1e40af;
      border-color: #1e40af;
    }
    .nav-link {
      color: #212529;
      transition: color 0.3s;
    }
    body.dark-mode .nav-link {
      color: #d1d5db;
    }
    .nav-link:hover,
    .nav-link:focus {
      color: #3b82f6 !important;
    }
    .dropdown-menu-dark {
      background-color: #2c2c2c;
      color: #e4e4e7;
    }
    .dropdown-menu-dark a.dropdown-item:hover,
    .dropdown-menu-dark a.dropdown-item:focus {
      background-color: #2563eb;
      color: white;
    }
    /* Custom menu toggle button */
    #menu-toggle-button {
      background: none;
      border: none;
      font-size: 1.5rem;
      color: #2563eb;
      cursor: pointer;
      transition: color 0.3s;
    }
    body.dark-mode #menu-toggle-button {
      color: #2563eb;
    }
    #menu-toggle-button:focus {
      outline: none;
    }
    /* Mobile menu styles */
    #mobile-menu {
      position: absolute;
      top: 56px;
      right: 1rem;
      width: 220px;
      background-color: white;
      border: 1px solid #ddd;
      border-radius: 0.375rem;
      box-shadow: 0 0.5rem 1rem rgb(0 0 0 / 0.15);
      opacity: 0;
      visibility: hidden;
      transform: translateY(-10px);
      transition: opacity 0.3s ease, transform 0.3s ease, visibility 0.3s;
      z-index: 1050;
    }
    body.dark-mode #mobile-menu {
      background-color: #2c2c2c;
      border-color: #444;
      color: #e4e4e7;
      box-shadow: 0 0.5rem 1rem rgb(0 0 0 / 0.5);
    }
    #mobile-menu.show {
      opacity: 1;
      visibility: visible;
      transform: translateY(0);
    }
    #mobile-menu a {
      display: block;
      padding: 0.75rem 1rem;
      color: inherit;
      text-decoration: none;
      border-bottom: 1px solid #ddd;
      transition: background-color 0.3s, color 0.3s;
    }
    body.dark-mode #mobile-menu a {
      border-color: #444;
    }
    #mobile-menu a:last-child {
      border-bottom: none;
    }
    #mobile-menu a:hover,
    #mobile-menu a:focus {
      background-color: #2563eb;
      color: white;
      outline: none;
    }
    /* Dark mode toggle button */
    #dark-mode-toggle {
      background: none;
      border: none;
      font-size: 1.25rem;
      color: #2563eb;
      cursor: pointer;
      transition: color 0.3s, transform 0.3s;
      padding: 0.25rem;
      border-radius: 0.375rem;
    }
    #menu-toggle-button {
      background: none;
      border: none;
      font-size: 1.25rem;
      color: #2563eb;
      cursor: pointer;
      transition: color 0.3s, transform 0.3s;
      padding: 0.25rem;
      border-radius: 0.375rem;
    }
    body.dark-mode #dark-mode-toggle {
      color: #2563eb;
    }
    #dark-mode-toggle:focus {
      outline: none;
      box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.5);
    }
    #menu-toggle-button:focus {
      outline: none;
      box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.5);
    }
    
    /* Icon rotation animation */
    .rotate-180 {
      transform: rotate(180deg);
      transition: transform 0.3s ease;
    }
    .rotate-0 {
      transform: rotate(0deg);
      transition: transform 0.3s ease;
    }
    /* Navbar container relative for absolute mobile menu */
    .navbar-container {
      position: relative;
    }
    /* Responsive adjustments */
    @media (min-width: 992px) {
      #mobile-menu {
        display: none !important;
      }
      #menu-toggle-button {
        display: none;
      }
      /* Move dark mode toggle to far right on desktop */
      .navbar-controls {
        display: flex;
        align-items: center;
        gap: 1rem;
      }
      .navbar-controls #dark-mode-toggle {
        order: 2;
        margin-left: auto;
      }
      .navbar-controls #menu-toggle-button {
        order: 1;
      }
    }
  </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow sticky-top navbar-container" id="main-navbar"><a class="nav-link px-3" href="index.html">Dashboard</a><a class="nav-link px-3" href="keyword_research.php">Keyword Research</a><a class="nav-link px-3" href="seo_score_analyzer.php">SEO Score Analyzer</a><a class="nav-link px-3" href="tag_rank_checker.php">Tag Rank Checker</a><a class="nav-link px-3" href="trending_videos.php">Trending Videos</a><a class="nav-link px-3" href="competitor_analyzer.php">Competitor Analyzer</a><a class="nav-link px-3" href="channel_audit.php">Channel Audit</a><a class="nav-link px-3" href="best_time_to_post.php">Best Time to Post</a><a class="nav-link px-3" href="ai_content_generator.php">AI Content Generator</a><a class="nav-link px-3" href="thumbnail_preview.php">Thumbnail Preview Simulator</a><a class="nav-link px-3" href="multi_lang_tags.php">Multi-language Tag Generator</a><a class="nav-link px-3" href="autocomplete_tags.php">Autocomplete Tag Scraper</a><a class="nav-link px-3" href="judul_analyzer.php">Judul Pesaing Analyzer</a></nav>
<main class="container flex-grow-1 py-5">
</main></body></html>