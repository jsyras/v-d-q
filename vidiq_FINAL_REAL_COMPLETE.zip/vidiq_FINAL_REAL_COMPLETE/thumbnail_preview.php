<?php include("template/header.php"); ?>

<h2>Thumbnail Preview Simulator</h2>
<p>Fitur ini akan menampilkan simulasi thumbnail (belum diimplementasi backend).</p>

<?php include("template/footer.php"); ?>