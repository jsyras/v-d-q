<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Channel Audit</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="container">
        <h2>Channel Audit</h2>
        <form method="post">
            <label>Channel ID:</label>
            <input type="text" name="channel_id" required><br><br>
            <button type="submit">Audit</button>
        </form>

        <div class="result">
            <?php
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $channel = escapeshellarg($_POST['channel_id']);
                $output = shell_exec("python3 py/audit_channel.py $channel");
                $data = json_decode($output, true);

                if (isset($data['error'])) {
                    echo "<p>Gagal mengambil data: " . htmlspecialchars($data['error']) . "</p>";
                } else {
                    echo "<h3>Channel: " . htmlspecialchars($data['channel_info']['title']) . "</h3>";
                    echo "<ul>";
                    echo "<li>Subscribers: " . number_format($data['channel_info']['subs']) . "</li>";
                    echo "<li>Total Views: " . number_format($data['channel_info']['views']) . "</li>";
                    echo "<li>Total Videos: " . number_format($data['channel_info']['videos']) . "</li>";
                    echo "<li>Rata-rata Views/Video: " . number_format($data['average_views']) . "</li>";
                    echo "</ul>";

                    echo "<h4>📈 Top Video:</h4>";
                    echo "<p><a href='https://www.youtube.com/watch?v=" . $data['top_video']['id'] . "' target='_blank'>" . htmlspecialchars($data['top_video']['title']) . "</a> (" . number_format($data['top_video']['views']) . " views)</p>";

                    echo "<h4>📉 Low Video:</h4>";
                    echo "<p><a href='https://www.youtube.com/watch?v=" . $data['low_video']['id'] . "' target='_blank'>" . htmlspecialchars($data['low_video']['title']) . "</a> (" . number_format($data['low_video']['views']) . " views)</p>";
                }
            }
            ?>
        </div>
    </div>
</body>
</html>
