<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Best Time to Post</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="container">
        <h2>Best Time to Post</h2>
        <form method="post">
            <label>Channel ID:</label>
            <input type="text" name="channel_id" required><br><br>
            <button type="submit">Analisa</button>
        </form>

        <div class="result">
            <?php
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $channel = escapeshellarg($_POST['channel_id']);
                $output = shell_exec("python3 py/best_time.py $channel");
                $data = json_decode($output, true);

                if ($data && isset($data['most_common_day'])) {
                    echo "<h3>Rekomendasi Waktu Upload</h3>";
                    echo "<ul>";
                    echo "<li><strong>Hari Terbaik:</strong> " . $data['most_common_day'] . "</li>";
                    echo "<li><strong>Jam Terbaik:</strong> " . $data['most_common_hour'] . ":00</li>";
                    echo "</ul>";
                } else {
                    echo "<p>Gagal mengambil data. Coba cek Channel ID dan API key di Python script.</p>";
                }
            }
            ?>
        </div>
    </div>
</body>
</html>
