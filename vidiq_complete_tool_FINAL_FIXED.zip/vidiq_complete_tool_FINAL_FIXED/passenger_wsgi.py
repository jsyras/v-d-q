import sys
import os

# Tambahkan path project ke sys.path
sys.path.insert(0, os.path.dirname(__file__))

def application(environ, start_response):
    status = '200 OK'
    output = b'Python App is running (WSGI entry point working).'

    response_headers = [('Content-type', 'text/plain'),
                        ('Content-Length', str(len(output)))]
    start_response(status, response_headers)

    return [output]
