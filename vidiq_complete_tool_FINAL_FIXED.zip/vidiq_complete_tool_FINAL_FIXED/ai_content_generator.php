<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>AI Content Generator</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="container">
        <h2>AI Content Generator</h2>
        <form method="post">
            <label>Masukkan Keyword Utama:</label>
            <input type="text" name="keyword" required><br><br>
            <button type="submit">Generate</button>
        </form>

        <div class="result">
            <?php
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $keyword = escapeshellarg($_POST['keyword']);
                $output = shell_exec("python3 py/ai_generator.py $keyword");
                $data = json_decode($output, true);

                if (isset($data['error'])) {
                    echo "<p>Gagal menghasilkan konten AI: " . htmlspecialchars($data['error']) . "</p>";
                } else {
                    echo "<h3>Judul:</h3><ul>";
                    foreach ($data['titles'] as $t) {
                        echo "<li>" . htmlspecialchars($t) . "</li>";
                    }
                    echo "</ul>";

                    echo "<h3>Deskripsi:</h3><p>" . htmlspecialchars($data['description']) . "</p>";

                    echo "<h3>Tags:</h3><p>" . implode(", ", array_map('htmlspecialchars', $data['tags'])) . "</p>";
                }
            }
            ?>
        </div>
    </div>
</body>
</html>
