<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Competitor Analyzer</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="container">
        <h2>Competitor Analyzer</h2>
        <form method="post">
            <label>Channel ID 1:</label>
            <input type="text" name="channel1" required><br><br>
            <label>Channel ID 2:</label>
            <input type="text" name="channel2" required><br><br>
            <button type="submit">Bandingkan</button>
        </form>

        <div class="result">
            <?php
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $ch1 = escapeshellarg($_POST['channel1']);
                $ch2 = escapeshellarg($_POST['channel2']);
                $output = shell_exec("python3 py/competitor_compare.py $ch1 $ch2");
                $data = json_decode($output, true);

                if ($data && $data['channel_1'] && $data['channel_2']) {
                    echo "<h3>Hasil Perbandingan:</h3>";
                    echo "<table border='1' cellpadding='10'><tr><th>Data</th><th>" . $data['channel_1']['title'] . "</th><th>" . $data['channel_2']['title'] . "</th></tr>";
                    echo "<tr><td>Subscribers</td><td>" . number_format($data['channel_1']['subs']) . "</td><td>" . number_format($data['channel_2']['subs']) . "</td></tr>";
                    echo "<tr><td>Total Views</td><td>" . number_format($data['channel_1']['views']) . "</td><td>" . number_format($data['channel_2']['views']) . "</td></tr>";
                    echo "<tr><td>Total Videos</td><td>" . number_format($data['channel_1']['videos']) . "</td><td>" . number_format($data['channel_2']['videos']) . "</td></tr>";
                    echo "</table>";
                } else {
                    echo "<p>Gagal mengambil data channel. Pastikan Channel ID benar dan API Key sudah diatur di Python script.</p>";
                }
            }
            ?>
        </div>
    </div>
</body>
</html>
