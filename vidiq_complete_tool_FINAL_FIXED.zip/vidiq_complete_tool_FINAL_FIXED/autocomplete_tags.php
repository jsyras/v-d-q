<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>YouTube Autocomplete Tag Scraper</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="container">
        <h2>YouTube Autocomplete Tag Scraper</h2>
        <form method="post">
            <label>Masukkan Keyword:</label>
            <input type="text" name="keyword" required><br><br>
            <button type="submit">Scrape Tags</button>
        </form>

        <div class="result">
            <?php
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $keyword = escapeshellarg($_POST['keyword']);
                $output = shell_exec("python3 py/autocomplete_scraper.py $keyword");
                $data = json_decode($output, true);

                if (isset($data['error'])) {
                    echo "<p>Gagal mengambil tag: " . htmlspecialchars($data['error']) . "</p>";
                } else {
                    echo "<h3>Hasil Autocomplete YouTube:</h3><ul>";
                    foreach ($data as $tag) {
                        echo "<li>" . htmlspecialchars($tag) . "</li>";
                    }
                    echo "</ul>";
                }
            }
            ?>
        </div>
    </div>
</body>
</html>
