import os
from dotenv import load_dotenv
load_dotenv()
import sys
import json
import requests

API_KEY = "YOUR_YOUTUBE_API_KEY"
channel_id = sys.argv[1]

def get_channel_info(channel_id):
    url = f"https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics&id={channel_id}&key={API_KEY}"
    r = requests.get(url).json()
    if not r.get("items"): return None
    info = r["items"][0]
    return {
        "title": info["snippet"]["title"],
        "subs": info["statistics"].get("subscriberCount", "0"),
        "views": info["statistics"].get("viewCount", "0"),
        "videos": info["statistics"].get("videoCount", "0")
    }

def get_video_ids(channel_id):
    url = f"https://www.googleapis.com/youtube/v3/search?key={API_KEY}&channelId={channel_id}&part=id&order=date&maxResults=50&type=video"
    r = requests.get(url).json()
    return [item["id"]["videoId"] for item in r.get("items", [])]

def get_video_stats(video_ids):
    all_data = []
    for i in range(0, len(video_ids), 50):
        batch = video_ids[i:i+50]
        ids = ",".join(batch)
        url = f"https://www.googleapis.com/youtube/v3/videos?key={API_KEY}&id={ids}&part=snippet,statistics"
        r = requests.get(url).json()
        for item in r.get("items", []):
            title = item["snippet"]["title"]
            views = int(item["statistics"].get("viewCount", 0))
            video_id = item["id"]
            all_data.append({"title": title, "views": views, "id": video_id})
    return all_data

channel_info = get_channel_info(channel_id)
video_ids = get_video_ids(channel_id)
videos = get_video_stats(video_ids)

if not channel_info or not videos:
    print(json.dumps({"error": "Data tidak ditemukan."}))
    exit()

videos_sorted = sorted(videos, key=lambda x: x["views"], reverse=True)
top_video = videos_sorted[0]
low_video = videos_sorted[-1]
average_views = sum(v["views"] for v in videos) // len(videos)

result = {
    "channel_info": channel_info,
    "top_video": top_video,
    "low_video": low_video,
    "average_views": average_views
}

print(json.dumps(result))
