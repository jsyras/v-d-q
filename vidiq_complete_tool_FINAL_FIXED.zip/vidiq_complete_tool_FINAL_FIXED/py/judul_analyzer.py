import os
from dotenv import load_dotenv
load_dotenv()
import sys
import json
import requests
import re
from urllib.parse import urlparse, parse_qs

API_KEY = "YOUR_YOUTUBE_API_KEY"

def extract_video_id(url):
    query = urlparse(url)
    if query.hostname == "youtu.be":
        return query.path[1:]
    if query.hostname in ("www.youtube.com", "youtube.com"):
        if query.path == "/watch":
            return parse_qs(query.query).get("v", [None])[0]
    return None

video_url = sys.argv[1]
video_id = extract_video_id(video_url)

if not video_id:
    print(json.dumps({"error": "Invalid video URL"}))
    sys.exit()

url = f"https://www.googleapis.com/youtube/v3/videos?part=snippet&id={video_id}&key={API_KEY}"
res = requests.get(url).json()

if "items" not in res or not res["items"]:
    print(json.dumps({"error": "Video not found"}))
    sys.exit()

title = res["items"][0]["snippet"]["title"]
title_length = len(title)
clickbait_words = ["you won't believe", "shocking", "top", "insane", "must watch", "unbelievable", "crazy", "exposed"]
clickbait_found = [w for w in clickbait_words if re.search(rf"\b{re.escape(w)}\b", title, re.IGNORECASE)]

result = {
    "title": title,
    "length": title_length,
    "clickbait_score": len(clickbait_found) * 10,
    "clickbait_words_found": clickbait_found
}

print(json.dumps(result))
