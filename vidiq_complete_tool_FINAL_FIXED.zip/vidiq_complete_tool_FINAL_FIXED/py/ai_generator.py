import os
from dotenv import load_dotenv
load_dotenv()
import sys
import json
import openai

openai.api_key = "YOUR_OPENAI_API_KEY"
keyword = sys.argv[1]

prompt = f"""
You are a YouTube content expert and SEO specialist.
Generate the following for the keyword: "{keyword}":

1. Three clickbait YouTube video titles.
2. One SEO-optimized video description (100-150 words).
3. A list of 10-15 SEO-relevant tags.

Format the response as JSON with keys: titles, description, tags.
"""

response = openai.ChatCompletion.create(
    model="gpt-3.5-turbo",
    messages=[{"role": "user", "content": prompt}],
    temperature=0.8,
    max_tokens=500
)

output = response['choices'][0]['message']['content']

try:
    parsed = json.loads(output)
    print(json.dumps(parsed))
except:
    print(json.dumps({"error": "Gagal parsing output AI"}))
