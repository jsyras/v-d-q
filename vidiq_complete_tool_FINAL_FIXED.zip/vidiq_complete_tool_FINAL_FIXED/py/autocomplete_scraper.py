import sys
import json
import requests

keyword = sys.argv[1]
url = f"https://suggestqueries.google.com/complete/search?client=firefox&ds=yt&q={keyword}"

headers = {
    "User-Agent": "Mozilla/5.0"
}

r = requests.get(url, headers=headers)
if r.status_code == 200:
    try:
        suggestions = r.json()[1]
        print(json.dumps(suggestions))
    except:
        print(json.dumps({"error": "Gagal parsing autocomplete"}))
else:
    print(json.dumps({"error": "Gagal mengambil data"}))
