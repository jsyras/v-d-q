import os
from dotenv import load_dotenv
load_dotenv()
import sys
import json
import openai

openai.api_key = "YOUR_OPENAI_API_KEY"
keyword = sys.argv[1]

prompt = f"""
Generate SEO-friendly YouTube video tags for the keyword: "{keyword}".
Return the tags in the following languages:
- English
- Spanish
- Indonesian
- Arabic
- Hindi

Each language should return 5-8 tags.
Respond in this JSON format:

{
  "English": [...],
  "Spanish": [...],
  "Indonesian": [...],
  "Arabic": [...],
  "Hindi": [...]
}
"""

response = openai.ChatCompletion.create(
    model="gpt-3.5-turbo",
    messages=[{"role": "user", "content": prompt}],
    temperature=0.7,
    max_tokens=500
)

output = response['choices'][0]['message']['content']

try:
    parsed = json.loads(output)
    print(json.dumps(parsed))
except:
    print(json.dumps({"error": "Gagal parsing output AI"}))
