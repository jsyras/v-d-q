import os
from dotenv import load_dotenv
load_dotenv()
import sys
import json
import requests

API_KEY = "YOUR_YOUTUBE_API_KEY"

def get_channel_stats(channel_id):
    url = f"https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics&id={channel_id}&key={API_KEY}"
    res = requests.get(url)
    data = res.json()

    if "items" not in data or not data["items"]:
        return None

    stats = data["items"][0]["statistics"]
    snippet = data["items"][0]["snippet"]
    return {
        "title": snippet["title"],
        "subs": stats.get("subscriberCount", "0"),
        "views": stats.get("viewCount", "0"),
        "videos": stats.get("videoCount", "0")
    }

ch1 = sys.argv[1]
ch2 = sys.argv[2]

data1 = get_channel_stats(ch1)
data2 = get_channel_stats(ch2)

result = {
    "channel_1": data1,
    "channel_2": data2
}

print(json.dumps(result))
