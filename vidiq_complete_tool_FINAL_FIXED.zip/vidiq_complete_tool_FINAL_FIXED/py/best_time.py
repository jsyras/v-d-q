import os
from dotenv import load_dotenv
load_dotenv()
import sys
import json
import requests
from datetime import datetime
from collections import Counter

API_KEY = "YOUR_YOUTUBE_API_KEY"
channel_id = sys.argv[1]

def get_video_data(channel_id):
    url = f"https://www.googleapis.com/youtube/v3/search?key={API_KEY}&channelId={channel_id}&part=snippet&order=date&maxResults=50&type=video"
    r = requests.get(url).json()
    return [{
        "id": item["id"]["videoId"],
        "publishedAt": item["snippet"]["publishedAt"]
    } for item in r.get("items", [])]

def get_video_views(video_ids):
    stats = {}
    for i in range(0, len(video_ids), 50):
        ids = ",".join(video_ids[i:i+50])
        url = f"https://www.googleapis.com/youtube/v3/videos?key={API_KEY}&id={ids}&part=statistics"
        r = requests.get(url).json()
        for item in r.get("items", []):
            vid = item["id"]
            views = int(item["statistics"].get("viewCount", 0))
            stats[vid] = views
    return stats

data = get_video_data(channel_id)
video_ids = [v["id"] for v in data]
views_dict = get_video_views(video_ids)

hour_counter = Counter()
day_counter = Counter()

for vid in data:
    pub_time = datetime.strptime(vid["publishedAt"], "%Y-%m-%dT%H:%M:%SZ")
    views = views_dict.get(vid["id"], 0)
    hour_counter[pub_time.hour] += 1
    day_counter[pub_time.strftime("%A")] += 1

top_day = day_counter.most_common(1)[0]
top_hour = hour_counter.most_common(1)[0]

result = {
    "most_common_day": top_day[0],
    "most_common_hour": top_hour[0],
    "upload_distribution_day": day_counter,
    "upload_distribution_hour": hour_counter
}

print(json.dumps(result))
