<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Multi-language Tag Generator</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="container">
        <h2>Multi-language Tag Generator</h2>
        <form method="post">
            <label>Masukkan Keyword Utama:</label>
            <input type="text" name="keyword" required><br><br>
            <button type="submit">Generate Tags</button>
        </form>

        <div class="result">
            <?php
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $keyword = escapeshellarg($_POST['keyword']);
                $output = shell_exec("python3 py/multi_lang_tags.py $keyword");
                $data = json_decode($output, true);

                if (isset($data['error'])) {
                    echo "<p>Gagal mengambil tag: " . htmlspecialchars($data['error']) . "</p>";
                } else {
                    echo "<h3>Tag Berdasarkan Bahasa:</h3>";
                    foreach ($data as $lang => $tags) {
                        echo "<h4>" . htmlspecialchars($lang) . "</h4>";
                        echo "<p>" . implode(", ", array_map('htmlspecialchars', $tags)) . "</p>";
                    }
                }
            }
            ?>
        </div>
    </div>
</body>
</html>
