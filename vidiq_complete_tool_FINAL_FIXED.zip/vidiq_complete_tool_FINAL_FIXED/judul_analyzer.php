<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Judul Pesaing Analyzer</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="container">
        <h2>Judul Pesaing Analyzer</h2>
        <form method="post">
            <label>Masukkan URL Video YouTube:</label>
            <input type="text" name="video_url" required><br><br>
            <button type="submit">Analisa</button>
        </form>

        <div class="result">
            <?php
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $url = escapeshellarg($_POST['video_url']);
                $output = shell_exec("python3 py/judul_analyzer.py $url");
                $data = json_decode($output, true);

                if (isset($data['error'])) {
                    echo "<p>Gagal mengambil data: " . htmlspecialchars($data['error']) . "</p>";
                } else {
                    echo "<h3>Hasil Analisa Judul</h3>";
                    echo "<ul>";
                    echo "<li><strong>Judul:</strong> " . htmlspecialchars($data['title']) . "</li>";
                    echo "<li><strong>Panjang Judul:</strong> " . $data['length'] . " karakter</li>";
                    echo "<li><strong>Skor Clickbait:</strong> " . $data['clickbait_score'] . "/100</li>";
                    echo "<li><strong>Kata Clickbait Ditemukan:</strong> " . implode(", ", array_map('htmlspecialchars', $data['clickbait_words_found'])) . "</li>";
                    echo "</ul>";
                }
            }
            ?>
        </div>
    </div>
</body>
</html>
