<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Thumbnail Preview Simulator</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .preview-box {
            display: flex;
            align-items: flex-start;
            gap: 15px;
            margin-top: 30px;
            background: #f1f1f1;
            padding: 15px;
            border-radius: 8px;
        }
        .preview-thumbnail {
            width: 168px;
            height: 94px;
            background: #ddd;
            object-fit: cover;
        }
        .preview-info {
            flex: 1;
        }
        .preview-title {
            font-weight: bold;
            font-size: 15px;
            margin-bottom: 5px;
        }
        .preview-channel {
            font-size: 13px;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Thumbnail Preview Simulator</h2>
        <form method="post">
            <label>Judul Video:</label>
            <input type="text" name="title" required><br><br>

            <label>URL Thumbnail:</label>
            <input type="text" name="thumbnail_url" required><br><br>

            <label>Nama Channel (opsional):</label>
            <input type="text" name="channel" placeholder="Channel Kamu"><br><br>

            <button type="submit">Preview</button>
        </form>

        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $title = htmlspecialchars($_POST['title']);
            $thumb = htmlspecialchars($_POST['thumbnail_url']);
            $channel = !empty($_POST['channel']) ? htmlspecialchars($_POST['channel']) : "Your Channel";

            echo "<div class='preview-box'>";
            echo "<img src='$thumb' alt='Thumbnail' class='preview-thumbnail'>";
            echo "<div class='preview-info'>";
            echo "<div class='preview-title'>$title</div>";
            echo "<div class='preview-channel'>$channel</div>";
            echo "</div></div>";
        }
        ?>
    </div>
</body>
</html>
